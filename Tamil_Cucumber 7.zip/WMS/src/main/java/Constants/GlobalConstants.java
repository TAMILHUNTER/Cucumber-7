package Constants;

public class GlobalConstants {

	public static final String Config_Properties_Loc = "./src/main/java/configuration/Configuration_QA.properties";
}
