package Constants;

public class BrowserConstants {
	
	public static final String Chrome_Driver_Path = "./drivers/chromedriver.exe";
	
	public static final String FireFox_Driver_Path = "./drivers/geckodriver-v0.26.0.exe";

}
